#!/bin/sh
g++ -std=gnu++11 -O3 /workdir/LineUp.cpp -o /workdir/LineUp
echo '/workdir/LineUp' > /workdir/command.txt