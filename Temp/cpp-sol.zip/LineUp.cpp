// C++11
#include <cstdlib>
#include <iostream>
#include <string>
#include <vector>

using namespace std;

class LineUp {
public:
    vector<int> getLineup(vector<int> heights, vector<int> arrangements) {
        vector<int> ret(arrangements.size());
        for (int i = 0; i < arrangements.size(); i++)
          ret[i] = i % heights.size();
        return ret;
    }
};
// -------8<------- end of solution submitted to the website -------8<-------

template<class T> void getVector(vector<T>& v) {
    for (int i = 0; i < v.size(); ++i)
        cin >> v[i];
}

int main() {
    LineUp sol;
    int size;
    cin >> size;
    vector<int> heights(size);
    getVector(heights);
    cin >> size;
    vector<int> arrangements(size);
    getVector(arrangements);
    vector<int> ret = sol.getLineup(heights, arrangements);
    cout << ret.size() << endl;
    for (int i = 0; i < ret.size(); i++)
      cout << ret[i] << endl;
    cout.flush();
}
